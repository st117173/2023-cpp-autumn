#ifndef CONSOLEHANDLER_H
#define CONSOLEHANDLER_H

#include "StringSearch.h"

class ConsoleHandler {
    public:
    void run();

    private:
    void correct(int &checkNumber);
};

#endif // CONSOLEHANDLER_H
