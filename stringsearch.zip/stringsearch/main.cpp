#include "ConsoleHandler.h"

int main()
{
    ConsoleHandler ch;
    ch.run();
    return 0;
}
